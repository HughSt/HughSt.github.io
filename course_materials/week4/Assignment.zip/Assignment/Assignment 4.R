## Assignment
# 1. Generate a correlogram and assess for global
# clustering using the hookworm prevalence data
# tanzania_uganda_hkprev.csv

# 2. Look for and map any clusters using Kulldorf scan statistic
# in the simulated case-control data
# cases_nairobi.csv
